var express = require('express');
var app = express.createServer(express.logger());
//app.set('title', "Grace's site");
app.use(express.bodyParser());

var mongoUri = 'mongodb://gbambushew:murray@dharma.mongohq.com:10038/scorecenter'
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
	collection=db.collection('highscores');
});	


app.use( function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });
 
 
 app.get('/', function (request, response) {
			
		collection.find().sort({game_title:1, score:-1}).toArray(function(err, docs){
			
			L=docs.length;
			str='Game: '+docs[0].game_title+'<br/><br/>Username: '+docs[0].username+'<br/>Score:'+docs[0].score+'<br/>';
			
			for(i=1; i<L; i++){	
				
				if(docs[i].game_title!==docs[i-1].game_title){
					str+='<br/><br/><br/>Game: '+docs[i].game_title+'<br/><br/>Username: '+docs[i].username+'<br/>Score: '+docs[i].score+'<br/>';
				}
				else{
				str+='Username: '+docs[i].username+'<br/>Score: '+docs[i].score+'<br/>';		
				}
			}
					
			response.send(str);
		});
	});


	
	
app.post('/', function(request, response){
	//response.send('Grace');
});



app.get('/highscores.json', function(request,response){
	
	gamename=request.query.game_title;
	
	if(gamename){
		collection.find({game_title:gamename}).sort({score:-1}).toArray(function(err, docs){
		
			L=docs.length;
			str=' ';
			if(L<10){
				for(i=0; i<L; i++){	
					str+='{"game_title":"'+docs[i].game_title+'","username":"'+docs[i].username+'","score":"'+docs[i].score+'","created_at":"'+docs[i].created_at+'","_id":"'+docs[i]._id+'"},';		
				}
			}
			else{
				for(i=0; i<10; i++){
					str+='{"game_title":"'+docs[i].game_title+'","username":"'+docs[i].username+'","score":"'+docs[i].score+'","created_at":"'+docs[i].created_at+'","_id":"'+docs[i]._id+'"},';		
				}
			}		
			response.send(str);
		});
	}
	else{
		collection.find().sort({score:-1}).toArray(function(err,docs){
			L=docs.length;
			str=' ';
			if(L<10){
				for(i=0; i<L; i++){	
					str+='{"game_title":"'+docs[i].game_title+'","username":"'+docs[i].username+'","score":"'+docs[i].score+'","created_at":"'+docs[i].created_at+'","_id":"'+docs[i]._id+'"},';		
				}
			}
			else{
				for(i=0; i<10; i++){
					str+='{"game_title":"'+docs[i].game_title+'","username":"'+docs[i].username+'","score":"'+docs[i].score+'","created_at":"'+docs[i].created_at+'","_id":"'+docs[i]._id+'"},';		
				}
			}
			response.send(str);	
		});
	}
});




app.post('/submit.json', function(request, response){
	var game_title=request.body.game_title;
	var username=request.body.username;
	var score=parseFloat(request.body.score);
	var date=request.body.created_at;
	collection.insert({'game_title':game_title, 'username':username,'score':score, 'created_at':date},{w:1}, function(err, result){});
});


app.get('/username',function(request,response){

	response.set('Content-Type', 'text/html');
	response.send("<!DOCTYPE html/><html><head>\
						<title>Username</title>\
						<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js'></script>\
						<script>\
							$(function(){\
								$('#submit').click(function(){\
								var nombre=$('#input').val();\
								var input={'username':nombre};\
								$.post('http://gentle-castle-5723.herokuapp.com/userfind', input);\
								});\
							});\
						</script>\
					</head>\
					<body>\
						<FORM action='http://gentle-castle-5723.herokuapp.com/userfind' method='get'>\
							<input type='text' id='input' name='name'>\
							<input type='submit' id='submit' value='Send'>\
						</FORM>\
					</body></html>");
					

});


app.post('/userfind',function(request,response){
	name_of_user=request.body.username;
});


app.get('/userfind', function(request,response){
	//response.send(name_of_user);
	
	collection.find({username:name_of_user}).sort({score:-1}).toArray(function(err, docs){	
		L=docs.length;
		str='Scores in all games for: '+name_of_user+'<br/><br/>';
			for(i=0; i<L; i++){	
				str+='Game: '+docs[i].game_title+'<br/>Score: '+docs[i].score+'<br/><br/>';		
			}
		response.send(str);
	});
});

var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});